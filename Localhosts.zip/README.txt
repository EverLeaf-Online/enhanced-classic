Fix for error:
	Check following boxes:
		*Comp Mode - windows 7
		*Override High DPI - App
		*Run as Admin

helps to turn off/down user account to level 0